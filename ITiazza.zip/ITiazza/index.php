<?php
/*
include 'mobile-detect.php';
$detect = new Mobile_Detect();

if ($detect->isMobile()) {
    header('Location: m/');
    exit(0);
}
else {
*/
    header('Location: html/index.php');
    exit(0);
//}
?>