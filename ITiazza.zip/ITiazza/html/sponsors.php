<!DOCTYPE html>
<html>
    <head>
        <title>Sponsors - ITiazza 2K15</title>
        
        <link rel="stylesheet" type="text/css" href="../styles/main.css">
        <link rel="stylesheet" type="text/css" href="../styles/sponsor.css">
        
        <script src="../js/jquery.js"></script>
        <script src="../js/animation.js"></script>
        <script src="../js/jarallax.js"></script>
        
    </head>
    
    <body onload="init()">
        <div class="content">
            
            <h1 id="heading">ITiazza 2K15</h1>
            
            <span class="behind"></span>
     <nav id="mainnav">
                <ul>
                    <li><a href="index.php">ITiazza</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="../gallery/">Gallery</a></li>
                    <li><a href="#">Sponsors</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </nav>
            
            <div id="sponsors">
                <div id="tech">
                    <span class="type">Tecnical Sponsor</span><br/>
                    <a href="http://www.esds.co.in" target="_blank"><img src="../images/sponsors/esds.gif"></a>
                </div>
                <div id="all">
                    <span class="type">Our Sponsors</span><br/>
                    <table>
                        <tr>
                            <td>
                                <a href="http://www.vyankateshdevelopers.com/" target="_blank"><img src="../images/sponsors/vyankatesh.gif"></a>
                            </td>
                            <td>
                                <a href="http://www.elceducation.com/" target="_blank"><img src="../images/sponsors/elc.gif"></a>
                            </td>
                            <td>
                                <a href="http://imecsurgical.com/" target="_blank"><img src="../images/sponsors/i-mec.gif"></a>
                            </td>
                            <td>
                                <img src="../images/sponsors/sports.gif">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <img src="../images/sponsors/Srushti.gif">
                            </td>
                            <td>
                                <a href="http://www.vasaneye.in/" target="_blank"><img src="../images/sponsors/vasan.gif"></a>
                            </td>
                            <td>
                                <img src="../images/sponsors/tulza.gif">
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="media">
                    <span class="type">Media Partner</span><br/>
                    <img src="../images/sponsors/gavkari.gif">
                </div>
            </div>
            
        </div>
    </body>
</html>