<!DOCTYPE html>
<html>
    <head>
        <title>About - ITiazza 2K15</title>
        
        <link rel="stylesheet" type="text/css" href="../styles/main.css">
        
        <script src="../js/jquery.js"></script>
        <script src="../js/animation.js"></script>
        <script src="../js/jarallax.js"></script>
        
    </head>
    
    <body onload="init()">
        <div class="content">
            
            <h1 id="heading">ITiazza 2K15</h1>
            
            <span class="behind"></span>
            <nav id="mainnav">
                <ul>
                    <li><a href="index.php">ITiazza</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="../gallery/">Gallery</a></li>
                    <li><a href="sponsors.php">Sponsors</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="#">About</a></li>
                </ul>
            </nav>
        </div>
	<div class="para">
		    <p style="text-align:justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ITIAZZA, Over The Past Ten Years has Witnessed Immensely Enthusiastic Participation, Growing Interest and Incorporation of Challenging Events. 'ITIAZZA-2K15' is Manifesting the Honorable Prime Minister, Mr. Narendra Modi's Vision 'MAKE IN INDIA' as their Theme, Which will also Emphasize the Contribution of The Information Technology Sector Towards the MAKE IN INDIA campaign.</p><br><br>
		    <p style="text-align:center;">We Invite You to Share Our Vision and Be Part of What Ensures to Carry Forward The Legacy of Technical Excellence.</p>
		    <p><b>&nbsp;&nbsp;JOIN US AT ITIAZZA 2K15 AND BE A PART OF IT.</b></p>     

	</div>
    </body>
</html>
