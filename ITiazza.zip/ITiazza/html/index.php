<!DOCTYPE html>
<html>
    <head>
        <title>ITiazza 2K15 - Make in India</title>
        
        <link rel="stylesheet" type="text/css" href="../styles/main.css">
    	<script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>
        <script type="text/javascript" src="../fancyBox/source/jquery.fancybox.js?v=2.1.5"></script>
        <link rel="stylesheet" type="text/css" href="../fancyBox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

        <script src="../js/animation.js"></script>
        <script src="../js/jarallax.js"></script>
        <script src="../js/html5shiv.js"></script>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    
    <body onload="init()">
        <div class="content">
            
            <h1 id="heading">ITiazza 2K15</h1>
            
            <span class="bmeter"></span>
            <span class="behind"></span>
            <a class="fancybox fancybox.iframe" href="../html/feedback.html" title="Feedback"><span class="planet1"></span></a>
            <a href="http://www.engg.kkwagh.edu.in/?pagesatish=kit_aboutdept" target="_blank" title="www.engg.kkwagh.edu.in"><span class="planet2"></span></a>
     
            <p id="p1">
                Hello! Welcome to The
            </p>
            <p id="p2">
                 National Level Technical Symposium
            </p>
            <p id="p3">
                Make in India <br>
	<img src="../images/blion.png" width="400" height="200" style="margin-bottom:10px;">
		
            </p>
            <nav id="mainnav">
                <ul>
                    <li><a href="#">ITiazza</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="../gallery/">Gallery</a></li>
                    <li><a href="sponsors.php">Sponsors</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </nav>
        </div>
        <script type="text/javascript">
                $(document).ready(function() {
                    $('.fancybox').fancybox();
                });
        </script>
    </body>
</html>
