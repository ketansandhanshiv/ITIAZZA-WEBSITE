<!DOCTYPE html>
<html>
    <head>
        <title>Events - ITiazza 2K15</title>
        
        <link rel="stylesheet" type="text/css" href="../styles/main.css">
    	<script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>
        <script type="text/javascript" src="../fancyBox/source/jquery.fancybox.js?v=2.1.5"></script>
        <link rel="stylesheet" type="text/css" href="../fancyBox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

        <script src="../js/animation.js"></script>
        <script src="../js/jarallax.js"></script>
        <script src="../js/html5shiv.js"></script>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    
    <body onload="init()">
        <div class="content">
            
            <h1 id="heading">ITiazza 2K15</h1>
            
            <span class="behind"></span>
     <nav id="mainnav">
                <ul>
                    <li><a href="index.php">ITiazza</a></li>
                    <li><a href="#">Events</a></li>
                    <li><a href="../gallery/">Gallery</a></li>
                    <li><a href="sponsors.php">Sponsors</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </nav>
        
            
            <a class="fancybox fancybox.iframe" href="../rules/pchunt_rule.html" title="PC HUNT RULES"><span class="e1">PC HUNT</span></a><br><span class="e1_d">Seek the treasure in PC</span>
            <a  class="fancybox fancybox.iframe" href="../rules/assemble_rule.html" title="ASSEMBLE THE PC RULES"><span class="e2">ASSEMBLE IT</span></a><br><span class="e2_d">Workshop & Contest to<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Assemble a CPU</span>
            <a class="fancybox fancybox.iframe" href="../rules/codewarz_rule.html" title="CODE WARZ RULES"><span class="e3">CODE WARZ</span></a><br><span class="e3_d">3 Level Coding Event</span>
            <a class="fancybox fancybox.iframe" href="../rules/crackon_rule.html" title="CRACK ON RULES"><span class="e4">CRACK ON</span></a><br><span class="e4_d">2 Level Aptitude & G.D</span>

            <a class="fancybox fancybox.iframe" href="../rules/brainbuzz_rule.html" title="BRAIN BUZZ RULES"><span class="e5">BRAIN BUZZ</span></a><br><span class="e5_d">Technical & GK Quiz</span>
            <a class="fancybox fancybox.iframe" href="../rules/creativeindia_rule.html" title="CREATIVE INDIA RULES"><span class="e6">CREATIVE INDIA</span></a><br><span class="e6_d">Poster Making Compitition</span>

            <a class="fancybox fancybox.iframe" href="../rules/gamerzden_rule.html" title="GAMERZ DEN RULES"><span class="e7">Clash of Lans</span></a><br><span class="e7_d">CS 1.6 Gaming Event</span>
            <a class="fancybox fancybox.iframe" href="../rules/exposure_rule.html" title="EXPOSURE RULES"><span class="e8">EXPOSURE</span></a><br><span class="e8_d">Campus Photography Event</span>

            
            
        </div>

        <script type="text/javascript">
                $(document).ready(function() {
                    $('.fancybox').fancybox();
                });
        </script>
    </body>
</html>