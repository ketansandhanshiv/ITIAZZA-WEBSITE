<!DOCTYPE html>
<html>
    <head>
        <title>Contact - ITiazza 2K15</title>
        
        <link rel="stylesheet" type="text/css" href="../styles/main.css">
        
        <script src="../js/jquery.js"></script>
        <script src="../js/animation.js"></script>
        <script src="../js/jarallax.js"></script>
        
    </head>
    
    <body onload="init()">
        <div class="content">
            
            <h1 id="heading">ITiazza 2K15</h1>
            
            <span class="behind"></span>
            <nav id="mainnav">
                <ul>
                    <li><a href="index.php">ITiazza</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="../gallery/">Gallery</a></li>
                    <li><a href="sponsors.php">Sponsors</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </nav>
        </div>
        <div class="para">
            <ul>	
                <li><p>Prof. Dr. K. N. Nandurkar (Principal), KKWIEER</p></li>
                <li><p>Prof. Dr. P. D. Bhamre (H.O.D. I.T)<br>email-id: kkw.hod.it@gmail.com</p></li>
                <li><p>Staff Co-ordinators :</p>
                    <p><blockquote>- Prof. S. K. Badjate<br>email-id: skbadjate@kkwagh.edu.in</blockquote></p>
                    <p><blockquote>- Prof. P. S. Vispute<br>email-id: psvispute@kkwagh.edu.in</blockquote></p> 
                <li><p>Student Co-ordinators:</p>
                <div class="div1">
                    <p><blockquote>- Ashish Patil<br>ph no. 8087543455</blockquote></p>
                    <p><blockquote>- Ameya Dighole<br>ph no. 8983047771</blockquote></p>				 
                </div>
                <div class="div2">
                    <p><blockquote>- Rahul Goswami<br>ph no. 9637513959</blockquote></p> 
                    <p><blockquote>- Aishwarya Shetty<br>ph no. 7776867821</blockquote></p> 
                </div>
            </ul>
        </div>
    </body>
</html>