<?php

session_start();

$email = $_REQUEST['email'] ;
$message = $_REQUEST['message'] ;

$_SESSION['email'] = $email;
$_SESSION['message'] = $message;

if(isset($email) && isset($message))
{
    if(!empty($email) && !empty($message))
    {
        $code = rand(11111, 99999);
        $_SESSION['code'] = $code;
        $subject = "ITiazza 2015 verification";
        $headers = "From: makeinindia@itiazza.in";
        
        $mail = 'This is a verification mail from ITiazza-15
                Please enter or copy the following verification code in the provided space to verify your account.
                Verification Code: '.$code.'
                Note: We don\'t store email addresses, this is just to verify your email address.
                Regards, ITIAZZA-15
                ';
        
        mail( $email, $subject, $mail, $headers );

        echo "<h1>ITiazza - 15 Feedback Form Verification</h1>
                ________________________________________________<br/>";
        echo "<p>\n<form method=\"post\" action=\"http://www.itiazza.in/html/sendmail.php\">\n
                Verification code has been mailed to \"".$email."\"
                <br/>Code: <input type=\"text\" name=\"code\">\n
                <input type=\"submit\" value=\"Verify\">\n
                </form>\n</p>";
    }
    else
        echo "<h3>Please fill in all the fields.";
}
else
    echo "<h3>Please fill in all the fields.";
?>