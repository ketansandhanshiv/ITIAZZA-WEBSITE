<?php

session_start();

$email = $_SESSION['email'];
$message = $_SESSION['message'];
$code = $_SESSION['code'];
$veri_code = $_POST['code'];

echo "<h1>ITiazza - 15 Feedback Form</h1>
            ________________________________________________<br/>\n";

if(isset($veri_code))
{
    if(!empty($veri_code))
    {
        if($veri_code == $code)
        {
            $to = "makeinindia@itiazza.in";
            $subject = "Feedback Form Results";
            $headers = "From: $email";
            
            mail( $to, $subject, $message, $headers );
            echo "<p><h3>Thank you for your feedback<br/>If your mail needs a reply, we usually reply within 24 hrs.</h3></p>";
        }
        else
        {
            echo "<p><h3>Invalid Verification code. Please try again</h3></p>";
            echo "<p>\n<form method=\"post\" action=\"http://www.itiazza.in/html/sendmail.php\">\n
                    Verification code has been mailed to \"".$email."\"
                    <br/>Code: <input type=\"text\" name=\"code\">\n
                    <input type=\"submit\" value=\"Verify\">\n
                    </form>\n</p>";
        }
    }
    else
    {
        echo "<p><h3>Please enter the verification code.</h3></p>";
        echo "<p>\n<form method=\"post\" action=\"http://www.itiazza.in/html/sendmail.php\">\n
                Code: <input type=\"text\" name=\"code\">\n
                <input type=\"submit\" value=\"Verify\">\n
                </form>\n</p>";
    }
}

?>